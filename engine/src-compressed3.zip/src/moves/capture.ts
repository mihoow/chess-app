import { SimpleMove } from './simple';

export class CaptureMove extends SimpleMove {}
